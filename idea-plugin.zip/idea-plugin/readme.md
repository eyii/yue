###1  AnAction::actionPerformed  相当于java中的main方法
###2加action配置 
resources/META-INF/plugin.xml
<action id="HelloWorld" class="HelloWorldAction" text="Say Hello!"><add-to-group group-id="WindowMenu" anchor="first"/></action>

###3打包
build--->Prepare plugin Module


###4安装
setting---->plugins------>选Install plugin from disk

5效果

Window菜单栏------“Say Hello!”选项


文章
http://www.jetbrains.org/intellij/sdk/docs/basics/getting_started/creating_an_action.html
https://blog.csdn.net/csdn_xpw/article/details/78946781

IntelliJ IDEA插件开发入门教程(一)


ctrl+1


