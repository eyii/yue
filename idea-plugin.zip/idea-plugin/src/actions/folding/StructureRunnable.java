package actions.folding;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.concurrent.Callable;

public class StructureRunnable implements Callable<String> {

    @Override
    public String call() throws Exception {
            folding();
           Thread.sleep(5);
            structure();
        return "1";
    }

    public String structure() throws Exception{
        Robot robot=new Robot();

        //    robot.setAutoDelay(5000);
        robot.keyPress(KeyEvent.VK_ALT);
        for (int i=1;i<=2;i++){
            robot.keyPress(KeyEvent.VK_7);
            robot.keyRelease(KeyEvent.VK_7);
        }
        robot.keyRelease(KeyEvent.VK_ALT);
        return null;
    }

    public String folding() throws Exception{
        Robot robot=new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        for (int i=1;i<=2;i++){
            robot.keyPress(KeyEvent.VK_SHIFT);
            robot.keyPress(KeyEvent.VK_MINUS);
            robot.keyRelease(KeyEvent.VK_MINUS);
            robot.keyRelease(KeyEvent.VK_SHIFT);
        }
        robot.keyRelease(KeyEvent.VK_CONTROL);
        return null;
    }
}
