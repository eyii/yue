package actions.folding;

import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.FileEditorManagerEvent;
import com.intellij.openapi.fileEditor.FileEditorManagerListener;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditorInject implements FileEditorManagerListener {


  public EditorInject(Project project) {


  }

  public void selectionChanged(FileEditorManagerEvent event) {


    FileEditorManagerListener.super.selectionChanged(event);

//
//    FileEditorManager source = event.getManager();
//    VirtualFile file = event.getNewFile();
//
//    System.out.println("file_name: " + file.getName());
  }


  public void fileOpened(FileEditorManager source, VirtualFile file) {
    FileEditorManagerListener.super.fileOpened(source, file);
   (Executors.newFixedThreadPool(10)).submit(new StructureRunnable());

  }

  public void fileClosed(FileEditorManager source, VirtualFile file) {
    FileEditorManagerListener.super.fileClosed(source, file);
  }

}
