package actions.folding.func;

import com.intellij.codeInsight.folding.impl.actions.CollapseAllRegionsAction;
import com.intellij.lang.ASTNode;
import com.intellij.lang.Language;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.FoldRegion;
import com.intellij.openapi.editor.FoldingModel;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.*;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.SearchScope;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public class FuncAction  extends AnAction {
    @Override
    public void actionPerformed(AnActionEvent event) {

//添加一个action，从事件里面e.getData(LocalDataKey.PsiElement)直接强转成PsiJavaFile
//然后PsiJavaFile对象中可以获取到class(PsiClass),里面方法，属性什么的都可以拿到。



        PsiJavaFile psi =(PsiJavaFile) event.getData(PlatformDataKeys.PSI_FILE);
        PsiClass[] psis=    psi.getClasses();

        PsiMethod[]  psiMethods= psis[0].getAllMethods();
         String   str=  psiMethods.toString();
      PsiMethod p1=  psiMethods[1];
        PsiParameterList plist=  p1.getParameterList();



   /*         final FoldingModel fm = editor.getFoldingModel();
        final Runnable runnable = new Runnable()
        {
            @Override
            public void run() {
                final Document document = editor.getDocument();
                final String text = document.getText();

                FoldRegion foldRegion = editor.getFoldingModel().getFoldRegion(1, 100);
                if ( foldRegion == null) foldRegion = editor.getFoldingModel().addFoldRegion(1, 100, "_");
            }
        };

        fm.runBatchFoldingOperationDoNotCollapseCaret(runnable);
        String title = "标题";
        String msg = "2018,起航";
        new CollapseAllRegionsAction();
        //  CodeFoldingManager cfm=e
        Messages.showMessageDialog(project, msg, title, Messages.getInformationIcon());*/
    }
}
