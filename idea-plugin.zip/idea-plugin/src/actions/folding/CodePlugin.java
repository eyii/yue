package actions.folding;

import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.fileEditor.FileEditorManagerListener;
import com.intellij.openapi.project.Project;

public class CodePlugin implements ProjectComponent {

  private Project project;

  public CodePlugin(Project pj) {

    project = pj;

  }

  private EditorInject inject;


  public String getComponentName() {

    return "plugin.CodePlugin";

  }

  public void disposeComponent() {
    ProjectComponent.super.disposeComponent();
  }

  public void projectClosed() {
    ProjectComponent.super.projectClosed();
  }

  public void initComponent() {
    ProjectComponent.super.initComponent();

    inject = new EditorInject(project);

    project.getMessageBus().connect().subscribe(FileEditorManagerListener.FILE_EDITOR_MANAGER, inject);
  }

  public void projectOpened() {
    ProjectComponent.super.projectOpened();
  }

}
