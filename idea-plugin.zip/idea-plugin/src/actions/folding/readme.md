https://blog.csdn.net/qq_15248459/article/details/78008992

idea插件 监听编辑板块切换