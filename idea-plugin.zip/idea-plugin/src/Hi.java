import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;

public class Hi extends AnAction {

    @Override
    public void actionPerformed(AnActionEvent e) {

    }
}
